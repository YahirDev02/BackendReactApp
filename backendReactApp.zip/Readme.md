run: npm init -y
run: npm i --save typescript
ts-node-dev ts-node-express
run: npm i -D @types/express

agregar script dev en el package.json
"dev": "ts-node-dev index.ts"

run: npm install cors
creamos un archivo ts en la carpeta middleware
